import{x as e,a6 as r,aD as t}from"./0XUr8-DF.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
