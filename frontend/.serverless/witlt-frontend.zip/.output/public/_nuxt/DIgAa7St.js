import{x as e,a6 as r,aE as t}from"./Bl2yBjn0.js";function u(o){return e(()=>r(o)?!!t(o)?.closest("form"):!0)}export{u};
