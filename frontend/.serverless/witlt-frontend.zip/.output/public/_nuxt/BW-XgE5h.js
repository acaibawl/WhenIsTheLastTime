import{b6 as e,F as o,x as i}from"./0XUr8-DF.js";function u(t){const r=e({dir:o("ltr")});return i(()=>t?.value||r.dir?.value||"ltr")}export{u};
