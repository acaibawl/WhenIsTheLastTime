import{ac as r}from"./Bl2yBjn0.js";function s(t,e="reka"){return`${e}-${r?.()}`}export{s as u};
