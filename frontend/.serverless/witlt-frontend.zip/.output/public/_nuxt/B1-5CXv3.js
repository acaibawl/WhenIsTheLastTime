import{ac as r}from"./0XUr8-DF.js";function s(t,e="reka"){return`${e}-${r?.()}`}export{s as u};
