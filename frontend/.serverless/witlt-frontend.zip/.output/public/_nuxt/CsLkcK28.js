import"./0XUr8-DF.js";const s=globalThis.setInterval;export{s};
