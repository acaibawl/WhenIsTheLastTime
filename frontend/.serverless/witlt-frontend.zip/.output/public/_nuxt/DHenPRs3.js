import"./Bl2yBjn0.js";const s=globalThis.setInterval;export{s};
